# 湛知正式成果包

- 数据集：ds-9433de079cc54581864c（系列 family-03d4f92453614afe9545）
- 数据集名称：教学数据集（40 名学生 / 2 个班）
- 运行：run-7151b4307fd54f9cb1e0
- 目录版本：catalog-20583c4b1ad24692a264
- 节点：N01、N02
- 生成时间：2026-11-28T08:59:33.954+00:00
- 快照：snap-44d3080676664c4cb1f6

## 生成方式（按模块记录）

| 模块 | 内容生成方式 | 复核方式 | 说明 |
| --- | --- | --- | --- |
| 导出打包 | 规则（rule） | 未单独记录 | 导出只读取冻结的正式版本并序列化，不调用模型 |
| A 知识体系 | 规则+模型（hybrid） | 未单独记录 | 知识版本中有 5 个知识点记录 review_info.method=model；该标记来自版本创建或复核时，不代表本次导出调用模型 |
| B 学情分析 | 规则+模型（hybrid） | 未单独记录 | 本包有 11 条语义诊断由模型生成并通过证据回查，其余 408 条为规则结果或待复核；模型尝试失败记录保留在 limitations |
| C 学习方案 | 规则（rule） 317 条 | 规则+模型（hybrid） 7 份、规则（rule） 152 份 | 推荐内容由规则生成（rule 317 条）；复核记录为 hybrid 7 份、rule 152 份。复核方式单独记录，不等于推荐内容由模型生成 |
| C 微课堂 | 模型（model） 6 份、规则（rule） 152 份 | 模型（model） 6 份、规则（rule） 152 份 | 微课堂正文生成方式：model 6 份、rule 152 份；复核记录：model 6 份、rule 152 份；正文生成方式与复核方式分开记录 |

模块来源取自正式版本载荷里的 `generation_method`、`creation_method` 与 `review_info`。
方案推荐内容按 `recommendation.generation_method` 统计，复核按 `review_info.method` 单独统计：
- C 学习方案：推荐内容 规则（rule） 317 条；复核记录 规则+模型（hybrid） 7 份、规则（rule） 152 份。
  本包推荐内容 317 条全部由规则生成（generation_method=rule），复核记录中 hybrid 7 份；复核方式不等于内容生成方式，不能把方案笼统称为模型生成。
- C 微课堂：正文 模型（model） 6 份、规则（rule） 152 份；复核记录 模型（model） 6 份、规则（rule） 152 份。
  正文生成方式按 `creation_method` 逐份统计，不用 hybrid 概括；知识或微课堂中的 `model` 标记
  可能来自版本创建或独立复核，不代表本次导出调用模型。
导出层只读冻结版本，不调用模型，也不把历史模型标记改写成规则。

## 数据来源

- 类型：official
- 是否合成：否
- 数据集：ds-9433de079cc54581864c（系列 family-03d4f92453614afe9545）
- 登记行数：dictionary 42、materials 65、nodes 2、records 806、requirements 9、students 40
- 说明：赛方提供的正式数据；使用范围以参赛授权与数据说明为准

数据来源类型取自导入登记（dataset_family.data_origin），
未与外部数据包原件逐项核对；不使用 `ready` 等状态词代替来源。

## 版本依赖

- 知识版本：kn-03465be407534636b73f（当前）
- 知识图谱：37 个知识点、11 条关系、58 条标注；`knowledge_graph.json` 的每条记录用 `knowledge_version` 区分版本，`current=false` 为历史依赖
- 冻结版本：学生学情 84、班级学情 4、学习方案 159、微课堂 158
- 依赖边：1127 条（`manifest.json` 的 `dependency_edges`）

## 版本链说明

- 当前方案 80 份，其中 4 份依赖历史学生学情版本：
- D01/N02：方案 plan-0c7163a07571480e9938（当前方案），引用学情 ban-b29e88b364934383a0ff；当前正式学情 ban-4ef797984fba4b1081b9。内容可追溯，但不是最新学情依据。
- D14/N02：方案 plan-0df6ab734edc4d499364（当前方案），引用学情 ban-c28da8c4962f4ac99d67；当前正式学情 ban-bff86476ec034338b297。内容可追溯，但不是最新学情依据。
- D17/N02：方案 plan-2b025ceb4efb4951b64d（当前方案），引用学情 ban-ad09f4b7d8b345308507；当前正式学情 ban-157a99ce1b264609b816。内容可追溯，但不是最新学情依据。
- D14/N01：方案 plan-306382f8ee5d42d2b0ae（当前方案），引用学情 ban-2153da7ecad64ebf890f；当前正式学情 ban-ba0bb58e18174dc89764。内容可追溯，但不是最新学情依据。
- 以上内容可追溯，但不是最新学情依据；`recommendations.json` 用 `analysis_current=false` 与 `basis_warnings` 标注，导出不改写版本，也不删除记录。
- 微课堂 158 份：挂当前方案 152 份、挂历史方案 6 份、方案版本无法确认 0 份；模型生成 6 份。`micro_lessons.json` 的 `plan_current` 标明微课堂挂在当前还是历史方案版本。
- 挂在历史方案版本的微课堂：lessonv-4589edae9680471b8371（rule，方案 plan-77f7d45dd7814db29c4b）、lessonv-4ab4b10ccd324141b533（rule，方案 plan-b85e78a1335645dc81dd）、lessonv-6b6c9965037448c5bafc（rule，方案 plan-77f7d45dd7814db29c4b）、lessonv-7adda28e6f214857b36d（rule，方案 plan-b85e78a1335645dc81dd）、lessonv-9a2a0d3d2938492ca698（rule，方案 plan-0f4c0d97985b41adb0de）、lessonv-ff80ea4fa04b42b1955d（rule，方案 plan-0f4c0d97985b41adb0de）；可追溯，但不是当前方案内容。

## 三项任务对应文件

1. 课程要求与知识体系：`curriculum.json`、`knowledge_graph.json`、`materials_index.json`
2. 学情分析：`student_analysis.json`、`class_analysis.json`、`metrics.csv`、`data_quality.json`
3. 个性化方案：`recommendations.json`、`micro_lessons.json`、`learning_history.json`

样例核查入口：`examples/input.json` 与 `examples/output.json` 按 `case_id` 一一对应。

## 核对方式

- 每个文件在 `manifest.json` 的 `files` 中都有 `sha256` 与 `bytes`，可直接校验；
- `manifest.json` 的 `publication` 记录每类版本的发布状态，`content_checks` 记录来源、
  摘要、难度与任务组字段的缺失数量；
- `evidence_records.json` 提供可解析的证据引用，指向冻结时的正式记录；
- `field_dictionary.json` 逐文件列出字段含义与空值语义。

## 回读校验

- preflight：passed
- payload：passed
- 内容检查：passed_with_limitations
- 检查报告：check-export-c48d3e7f81774c04a463
- 检查时间：2026-11-28T08:59:34.943+00:00

payload 表示回读校验（文件存在、哈希、JSON/CSV 可解析）；内容检查单独记录
来源、摘要、难度与任务组字段的缺失项，不把文件校验通过当成业务内容合格。
只有 payload 为 passed 时，manifest 才写入报告 ID 与时间；未执行或失败保持 pending/failed。
内容检查问题：7 条材料缺少可解析知识点引用；65 条材料难度未知；88 份学情结果没有正式摘要；158 份微课堂没有教材来源引用

## 适用边界

- 本包冻结自提交时的正式版本，之后的新作答与新版方案不会改变本包；
- 学情结论保留证据充分性与限制，未把"无记录"当作 0 分；
- 学生/班级 `result.publication_status` 取自正式发布记录；`summary=null` 表示正式结果
  没有提供摘要字段，不代表没有结论；
- 材料来源与知识点关联只投影目录和知识标注里已有的证据；缺失时标 unverified/unknown，
  不补造教材页码；
- 微课堂引用组件按 `source_refs`/`evidence_refs` 的索引解析；没有教材来源时标
  evidence_only/unverified，不显示成已引用教材；
- 任务组 `teacher_reason`/`primary_strategy` 为空时如实保留，导出层不补写；
- 以下限制来自本包内容检查：
- 包内含历史依赖版本：student_analysis.json 与 recommendations.json 以 current=false 标记
- 学情摘要为空：88 份学生/班级正式结果的 summary 为 null（其中当前版本 84 份）。B 未提供摘要字段，导出保留 null 并用 summary_status=not_provided 标明，结论以 metrics、findings 与 evidence_refs 为准
- 材料难度未知：65 条材料的目录 difficulty 为 null。导出把 difficulty_level/difficulty_status 标为 unknown，不按历史得分或题干猜测难度
- 微课堂教材来源：158/158 份的正文 source_refs 为空。这些微课堂按 evidence_only/unverified 输出，引用组件只指向证据索引，不显示成已引用教材原文
- 版本链：4 份当前方案基于历史学生学情版本（D01/N02、D14/N02、D17/N02、D14/N01）。这些方案与分析版本可追溯，但不是最新学情依据；recommendations.json 用 analysis_current=false 与 basis_warnings 标注，导出不改写版本，也不删除历史记录
- 版本链：6 份微课堂挂在历史方案版本；micro_lessons.json 用 plan_current=false 标注，可追溯但不是当前方案内容
